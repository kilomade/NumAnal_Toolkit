To run the project from the command line, go to the dist folder and
type the following:

java -jar "NumAnal.jar" 

To run the project from desktop, unzip this folder and double click:

"NumAnal.jar"


For inquires, contact Christian Taylor - christiant.taylor@yahoo.com